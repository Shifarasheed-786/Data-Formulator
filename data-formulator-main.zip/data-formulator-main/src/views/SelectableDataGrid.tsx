// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

import * as React from 'react';
import { useTranslation } from 'react-i18next';
import { shadow, transition } from '../app/tokens';
import { TableVirtuoso } from 'react-virtuoso';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import { Box } from '@mui/system';

import { useTheme } from '@mui/material/styles';
import { alpha, Paper, Tooltip, CircularProgress, Fade } from "@mui/material";

import { Type } from '../data/types';
import { getIconFromType } from './ViewUtils';

import { IconButton, TableSortLabel, Typography } from '@mui/material';

import _ from 'lodash';
import * as d3 from 'd3-dsv';
import { FieldSource, FieldItem } from '../components/ComponentType';

import FileDownloadIcon from '@mui/icons-material/FileDownload';
import { TableIcon } from '../icons';
import CasinoIcon from '@mui/icons-material/Casino';
import ArrowUpwardIcon from '@mui/icons-material/ArrowUpward';
import ArrowDownwardIcon from '@mui/icons-material/ArrowDownward';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import FilterAltIcon from '@mui/icons-material/FilterAlt';
import { getUrls, fetchWithIdentity } from '../app/utils';
import { apiRequest, assertDownloadResponseOk } from '../app/apiClient';
import { useDrag } from 'react-dnd';
import { useSelector } from 'react-redux';
import { DataFormulatorState } from '../app/dfSlice';
import { ColumnFilter, ColumnFilterPopover } from './ColumnFilterPopover';

export interface ColumnDef {
    id: string;
    label: string;
    dataType: Type;
    description?: string;
    minWidth?: number;
    width?: number;
    align?: 'right';
    format?: (value: number) => string | JSX.Element;
    source: FieldSource;
}

interface SelectableDataGridProps {
    tableId: string;
    tableName: string;
    rows: any[];
    rowCount: number;
    virtual: boolean;
    columnDefs: ColumnDef[];
}

function descendingComparator<T>(a: T, b: T, orderBy: keyof T) {
    if (b[orderBy] < a[orderBy]) {
        return -1;
    }
    if (b[orderBy] > a[orderBy]) {
        return 1;
    }
    return 0;
}

function getComparator<Key extends keyof any>(
    order: "asc" | "desc",
    orderBy: Key,
): (
    a: { [key in Key]: number | string },
    b: { [key in Key]: number | string },
) => number {
    return order === 'desc'
        ? (a, b) => descendingComparator(a, b, orderBy)
        : (a, b) => -descendingComparator(a, b, orderBy);
}

// Get color for field source hover highlight
function getColorForFieldSource(source: string | undefined, theme: any): string {
    if (!source) {
        return theme.palette.primary.main; // Default to primary for original fields
    }
    
    switch (source) {
        case "custom":
            return theme.palette.custom.main; // Orange for custom fields
        case "original":
        default:
            return theme.palette.primary.main; // Blue for original fields
    }
}

// Draggable header component
interface DraggableHeaderProps {
    columnDef: ColumnDef;
    orderBy: string | undefined;
    order: 'asc' | 'desc';
    onSortAsc: () => void;
    onSortDesc: () => void;
    onClearSort: () => void;
    onOpenFilter: (anchor: HTMLElement) => void;
    hasFilter: boolean;
    tableId: string;
}

const DraggableHeader: React.FC<DraggableHeaderProps> = ({ 
    columnDef, orderBy, order, onSortAsc, onSortDesc, onClearSort,
    onOpenFilter, hasFilter, tableId
}) => {
    const { t } = useTranslation();
    const filterButtonRef = React.useRef<HTMLButtonElement | null>(null);
    const kebabButtonRef = React.useRef<HTMLButtonElement | null>(null);
    const isSorted = orderBy === columnDef.id;
    const cycleSort = () => {
        if (!isSorted) { onSortAsc(); return; }
        if (order === 'asc') { onSortDesc(); return; }
        onClearSort();
    };
    const theme = useTheme();
    const conceptShelfItems = useSelector((state: DataFormulatorState) => state.conceptShelfItems);
    const semanticType = useSelector(
        (state: DataFormulatorState) => state.tables.find(t => t.id === tableId)?.metadata?.[columnDef.id]?.semanticType,
    );
    
    // Find the corresponding FieldItem for this column
    // Try to find by name first, then by constructing the ID for original fields
    const field = conceptShelfItems.find(f => f.name === columnDef.id) || 
                  conceptShelfItems.find(f => f.id === `original--${tableId}--${columnDef.id}`);
    
    // Only make draggable if we have a field
    // react-dnd has a drag threshold, so clicks will still work for sorting
    const [{ isDragging }, dragSource, dragPreview] = useDrag(() => ({
        type: "concept-card",
        item: field ? { 
            type: 'concept-card', 
            fieldID: field.id, 
            source: "conceptShelf" 
        } : undefined,
        canDrag: !!field,
        collect: (monitor) => ({
            isDragging: monitor.isDragging(),
            handlerId: monitor.getHandlerId(),
        }),
    }), [field]);

    let backgroundColor: string;
    let borderBottomColor = theme.palette.primary.main;
    if (columnDef.source == "custom") {
        backgroundColor = theme.palette.custom.bgcolor || alpha(theme.palette.custom.main, 0.1);
        borderBottomColor = theme.palette.custom.main;
    } else {
        backgroundColor = theme.palette.primary.bgcolor || alpha(theme.palette.primary.main, 0.1);
        borderBottomColor = theme.palette.primary.main;
    }

    const opacity = isDragging ? 0.3 : 1;
    const cursorStyle = field ? (isDragging ? "grabbing" : "grab") : "default";
    
    // Enhanced background color on hover for draggable headers - based on field source (derived/original)
    const hoverBackgroundColor = field 
        ? alpha(getColorForFieldSource(field.source, theme), 0.1)
        : backgroundColor;

    return (
        <Box 
            className="data-view-header-container" 
            ref={dragPreview}
            sx={{ 
                backgroundColor: backgroundColor, 
                borderBottomColor, 
                borderBottomWidth: '2px', 
                borderBottomStyle: 'solid',
                opacity,
                display: 'flex',
                alignItems: 'center',
                position: 'relative',
                transition: 'background-color 0.2s ease, box-shadow 0.2s ease',
                // Ensure cursor applies to TableSortLabel and its children, but not IconButton
                '& .data-view-header-title, & .data-view-header-title *': {
                    cursor: cursorStyle,
                },
                ...(field && {
                    '&:hover': {
                        backgroundColor: hoverBackgroundColor,
                        boxShadow: shadow.md,
                    },
                }),
            }}
        >
            {/* Main content area - draggable for concepts, using original TableSortLabel structure */}
            <TableSortLabel
                ref={field ? dragSource : undefined}
                className="data-view-header-title"
                sx={{ 
                    display: "flex", 
                    flexDirection: "row", 
                    flex: 1,
                    width: 'calc(100% - 24px)',
                    cursor: cursorStyle, // Inherit cursor from parent
                    '& .MuiTableSortLabel-icon': {
                        display: 'none',
                    },
                }}
                active={isSorted}
                direction={isSorted ? order : 'asc'}
                onClick={(e) => {
                    // Prevent sort when dragging
                    if (!isDragging) {
                        e.stopPropagation();
                        cycleSort();
                    }
                }}
            >
                <span role="img" style={{ fontSize: "inherit", padding: "2px", display: "inline-flex", alignItems: "center" }}>
                    {getIconFromType(columnDef.dataType)}
                </span>
                <Tooltip 
                    title={(semanticType || columnDef.description) ? (
                        <Box>
                            {semanticType && (
                                <Typography sx={{ fontSize: 11 }}>
                                    <b>{columnDef.label}</b>: <i>{semanticType}</i>
                                </Typography>
                            )}
                            {columnDef.description && (
                                <Typography sx={{ fontSize: 11, color: 'grey.300', mt: semanticType ? 0.25 : 0 }}>
                                    {columnDef.description}
                                </Typography>
                            )}
                        </Box>
                    ) : ''}
                    arrow
                    placement="top"
                >
                    <Typography sx={{fontSize: 12, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap'}}>
                        {columnDef.label}
                    </Typography>
                </Tooltip>
                {isSorted && (
                    <Box component="span" sx={{ display: 'inline-flex', alignItems: 'center', ml: 0.25, color: theme.palette.primary.main }}>
                        {order === 'asc'
                            ? <ArrowUpwardIcon sx={{ fontSize: 13 }} />
                            : <ArrowDownwardIcon sx={{ fontSize: 13 }} />}
                    </Box>
                )}
            </TableSortLabel>
            {/* Inline filter status hint \u2014 only rendered when a filter is active on this column.
                Clicking reopens the filter popover. */}
            {hasFilter && (
                <Tooltip title={<Typography sx={{fontSize: 10}}>{t('dataGrid.columnMenu.filterActive')}</Typography>}>
                    <IconButton
                        ref={filterButtonRef}
                        size="small"
                        onClick={(e) => {
                            e.stopPropagation();
                            onOpenFilter(e.currentTarget);
                        }}
                        sx={{
                            padding: '2px',
                            marginLeft: '2px',
                            color: theme.palette.primary.main,
                            '&:hover': {
                                backgroundColor: alpha(theme.palette.action.hover, 0.2),
                            },
                        }}
                    >
                        <FilterAltIcon sx={{ fontSize: 14 }} />
                    </IconButton>
                </Tooltip>
            )}
            {/* Column kebab — single entry point that opens the unified
                sort + filter popover (design-doc 31 §4.2). */}
            <Tooltip title={<Typography sx={{fontSize: 10}}>{t('dataGrid.columnMenu.openMenu')}</Typography>}>
                <IconButton
                    ref={kebabButtonRef}
                    size="small"
                    onClick={(e) => {
                        e.stopPropagation();
                        onOpenFilter(e.currentTarget);
                    }}
                    sx={{
                        padding: '2px',
                        marginLeft: '1px',
                        marginRight: '2px',
                        color: alpha(theme.palette.text.primary, 0.55),
                        '&:hover': {
                            color: theme.palette.text.primary,
                            backgroundColor: alpha(theme.palette.action.hover, 0.2),
                        },
                    }}
                >
                    <MoreVertIcon sx={{ fontSize: 15 }} />
                </IconButton>
            </Tooltip>
        </Box>
    );
};

// Stable TableVirtuoso sub-components — defined once outside the render cycle
// so react-virtuoso never sees new component references on re-render.
const VirtuosoScroller = React.forwardRef<HTMLDivElement>((props, ref) => (
    <TableContainer {...props} ref={ref} />
));
const VirtuosoTableHead = React.forwardRef<HTMLTableSectionElement, React.HTMLAttributes<HTMLTableSectionElement>>((props, ref) => (
    <TableHead {...props} ref={ref} className='table-header-container' style={{ ...props.style, display: 'table-header-group' }} />
));
const VirtuosoTableRow = (props: any) => {
    const index = props['data-index'];
    return <TableRow {...props} style={{...props.style, backgroundColor: index % 2 == 0 ? "rgba(255, 255, 255, 0.05)" : "rgba(0, 0, 0, 0.02)"}}/>
};
const VirtuosoTableBody = React.forwardRef<HTMLTableSectionElement>((props, ref) => (
    <TableBody {...props} ref={ref} />
));

const PAGE_SIZE = 500;

export const SelectableDataGrid: React.FC<SelectableDataGridProps> = React.memo(({ 
    tableId, rows, tableName, columnDefs, rowCount, virtual }) => {

    const { t } = useTranslation();
    const [orderBy, setOrderBy] = React.useState<string | undefined>(undefined);
    const [order, setOrder] = React.useState<'asc' | 'desc'>('asc');

    // Column filter state — keyed by column id. Presence of an entry means
    // the column has an active filter (design-doc 31). Server-side pushdown
    // is handled by fetchVirtualData; non-virtual tables ignore filters in v1.
    const [columnFilters, setColumnFilters] = React.useState<Record<string, ColumnFilter>>({});
    const [filterPopover, setFilterPopover] = React.useState<{ columnId: string; anchor: HTMLElement } | null>(null);

    // Lookup of per-column metadata (distinctCount/nullCount/levels/levelCounts/type)
    // to drive the filter popover's variant selection synchronously.
    const tableMetadata = useSelector(
        (state: DataFormulatorState) => state.tables.find(t => t.id === tableId)?.metadata,
    );

    // Ref-based bridge to fetchVirtualData (declared further below); lets stable
    // sort handlers call into the latest fetch function without re-creating themselves.
    const fetchVirtualDataRef = React.useRef<((sortByColumnIds: string[], sortOrder: 'asc' | 'desc', offset?: number, append?: boolean) => void) | null>(null);

    const applySort = React.useCallback((newOrderBy: string | undefined, newOrder: 'asc' | 'desc') => {
        setOrder(newOrder);
        setOrderBy(newOrderBy);
        if (virtual) {
            fetchVirtualDataRef.current?.(newOrderBy ? [newOrderBy] : [], newOrder);
        }
    }, [virtual]);

    let theme = useTheme();

    const [rowsToDisplay, setRowsToDisplay] = React.useState<any[]>(rows);
    
    const [isLoading, setIsLoading] = React.useState<boolean>(true);
    const [isLoadingMore, setIsLoadingMore] = React.useState<boolean>(false);
    const [isDownloading, setIsDownloading] = React.useState<boolean>(false);
    const [hasMore, setHasMore] = React.useState<boolean>(virtual ? rows.length < rowCount : false);
    const fetchIdRef = React.useRef(0);
    
    React.useEffect(() => {
        setIsLoading(false);
    }, []);

    React.useEffect(() => {
        if (orderBy && !isLoading && !virtual) {
            setRowsToDisplay(rows.slice().sort(getComparator(order, orderBy)));
        } else if (!virtual) {
            setRowsToDisplay(rows);
        }
        if (!virtual) {
            setHasMore(false);
        }
    }, [rows, order, orderBy])

    // Only the Table component depends on columnDefs (for colgroup); memoize it
    // so react-virtuoso keeps a stable reference when columns haven't changed.
    const columnIds = columnDefs.map(c => c.id).join(',');
    const VirtuosoTable = React.useMemo(() => {
        const Comp = ({ children, style, ...rest }: any) => (
            <Table {...rest} style={style} sx={{ tableLayout: 'fixed', width: '100%' }}>
                <colgroup>
                    {columnDefs.map(col => (
                        <col key={col.id} style={col.id === '#rowId' ? { width: 56 } : undefined} />
                    ))}
                </colgroup>
                {children}
            </Table>
        );
        return Comp;
    }, [columnIds]);

    const tableComponents = React.useMemo(() => ({
        Scroller: VirtuosoScroller,
        Table: VirtuosoTable,
        TableHead: VirtuosoTableHead,
        TableRow: VirtuosoTableRow,
        TableBody: VirtuosoTableBody,
    }), [VirtuosoTable]);

    const handleDownload = async (format: 'csv' | 'tsv') => {
        if (isDownloading) return;
        const delimiter = format === 'tsv' ? '\t' : ',';
        const ext = format === 'tsv' ? 'tsv' : 'csv';
        const mime = format === 'tsv' ? 'text/tab-separated-values' : 'text/csv';

        setIsDownloading(true);
        try {
            if (virtual) {
                const response = await fetchWithIdentity(getUrls().EXPORT_TABLE_CSV, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ table_name: tableId, delimiter }),
                });
                await assertDownloadResponseOk(response, 'Export failed');
                const blob = await response.blob();
                const a = document.createElement('a');
                a.href = URL.createObjectURL(blob);
                a.download = `${tableName}.${ext}`;
                a.click();
                URL.revokeObjectURL(a.href);
            } else {
                const csvContent = d3.dsvFormat(delimiter).format(rows);
                const blob = new Blob([csvContent], { type: mime });
                const a = document.createElement('a');
                a.href = URL.createObjectURL(blob);
                a.download = `${tableName}.${ext}`;
                a.click();
                URL.revokeObjectURL(a.href);
            }
        } catch (error) {
            console.error('Error downloading table:', error);
        } finally {
            setIsDownloading(false);
        }
    };

    // Hold the live filters in a ref so fetchVirtualData stays stable yet
    // always reads the latest set when called from sort/scroll handlers.
    const filtersRef = React.useRef<ColumnFilter[]>([]);
    React.useEffect(() => {
        filtersRef.current = Object.values(columnFilters);
    }, [columnFilters]);

    const fetchVirtualData = React.useCallback((
        sortByColumnIds: string[],
        sortOrder: 'asc' | 'desc',
        offset: number = 0,
        append: boolean = false,
    ) => {
        if (!append) {
            setIsLoading(true);
        } else {
            setIsLoadingMore(true);
        }

        const currentFetchId = ++fetchIdRef.current;

        const activeFilters = filtersRef.current;
        const message: Record<string, any> = {
            table: tableId,
            size: PAGE_SIZE,
            offset,
            method: sortByColumnIds.length > 0
                ? (sortOrder === 'asc' ? 'head' : 'bottom')
                : 'head',
            order_by_fields: sortByColumnIds.length > 0 ? sortByColumnIds : ['#rowId'],
            ...(activeFilters.length > 0 ? { filters: activeFilters } : {}),
        };

        apiRequest<any>(getUrls().SAMPLE_TABLE, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(message),
        })
        .then(({ data }) => {
            if (fetchIdRef.current !== currentFetchId) return;
            const newRows = data.rows || [];
            const totalCount = data.total_row_count ?? rowCount;

            if (append) {
                setRowsToDisplay(prev => [...prev, ...newRows]);
            } else {
                setRowsToDisplay(newRows);
            }
            setHasMore(offset + newRows.length < totalCount);
            setIsLoading(false);
            setIsLoadingMore(false);
        })
        .catch(error => {
            if (fetchIdRef.current !== currentFetchId) return;
            console.error('Error fetching sorted table data:', error);
            setIsLoading(false);
            setIsLoadingMore(false);
        });
    }, [tableId, rowCount]);

    // Keep the ref in sync so stable handlers (e.g. applySort) can call the latest version.
    React.useEffect(() => {
        fetchVirtualDataRef.current = fetchVirtualData;
    }, [fetchVirtualData]);

    // Refetch from offset 0 whenever filters change (virtual tables only).
    // Skip the initial mount; the first load happens via the existing
    // virtual-data effect.
    const didMountFiltersRef = React.useRef(false);
    React.useEffect(() => {
        if (!virtual) return;
        if (!didMountFiltersRef.current) {
            didMountFiltersRef.current = true;
            return;
        }
        fetchVirtualData(orderBy ? [orderBy] : [], order, 0, false);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [columnFilters]);

    const handleEndReached = React.useCallback(() => {
        if (!virtual || !hasMore || isLoadingMore || isLoading) return;
        fetchVirtualData(
            orderBy ? [orderBy] : [],
            order,
            rowsToDisplay.length,
            true,
        );
    }, [virtual, hasMore, isLoadingMore, isLoading, fetchVirtualData, orderBy, order, rowsToDisplay.length]);

    return (
        <Box className="table-container table-container-small"
            sx={{
                width: '100%',
                height: '100%',
                position: 'relative',
                "& .MuiTableCell-root": {
                    fontSize: 12, maxWidth: "120px", py: '2px', cursor: "default",
                    overflow: "clip", textOverflow: "ellipsis", whiteSpace: "nowrap"
                }
            }}>
            {/* Loading Overlay */}
            {isLoading && (
                <Box sx={{ 
                    position: 'absolute', 
                    top: 0, 
                    left: 0, 
                    right: 0,
                    zIndex: 10, 
                    display: 'flex', 
                    alignItems: 'center', 
                    justifyContent: 'center',
                    backgroundColor: 'rgba(255, 255, 255, 0.7)',
                    padding: '8px',
                    height: '100%',
                    borderTopLeftRadius: '4px',
                    borderTopRightRadius: '4px'
                }}>
                    <CircularProgress size={24} sx={{ mr: 1, color: 'lightgray' }} />
                    <Typography variant="body2" color="text.secondary">{t('dataGrid.loading')}</Typography>
                </Box>
            )}
            <Fade in={!isLoading} timeout={{appear: 300, enter: 300, exit: 2000}}>
                <Box sx={{ flex: '1 1', display: 'flex', flexDirection: 'column' }}>
                    <TableVirtuoso
                            style={{ flex: '1 1', paddingBottom: 32 }}
                            data={rowsToDisplay}
                            components={tableComponents}
                            endReached={handleEndReached}
                            overscan={200}
                            fixedHeaderContent={() => {
                        return (
                            <TableRow key='header-fixed' style={{ paddingRight: 0, marginRight: '17px', height: '24px'}}>
                                {columnDefs.map((columnDef, index) => {
                                    return (
                                        <TableCell
                                            className='data-view-header-cell'
                                            key={columnDef.id}
                                            align={columnDef.align}
                                            sx={{
                                                p: columnDef.id === '#rowId' ? '0 2px' : 0,
                                                minWidth: columnDef.minWidth,
                                                width: columnDef.width,
                                            }}
                                        >
                                            {columnDef.id === '#rowId' ? (
                                                <Box
                                                    className="data-view-header-container"
                                                    sx={{
                                                        display: 'flex',
                                                        alignItems: 'center',
                                                        justifyContent: 'center',
                                                        borderBottomWidth: '2px',
                                                        borderBottomStyle: 'solid',
                                                        borderBottomColor: 'rgba(0,0,0,0.2)',
                                                        padding: '4px 4px',
                                                        margin: '0 2px 0 0',
                                                    }}
                                                >
                                                    <Typography
                                                        sx={{
                                                            fontSize: 12,
                                                            color: 'text.secondary',
                                                            whiteSpace: 'nowrap',
                                                        }}
                                                    >
                                                        {columnDef.label}
                                                    </Typography>
                                                </Box>
                                            ) : (
                                                <DraggableHeader
                                                    columnDef={columnDef}
                                                    orderBy={orderBy}
                                                    order={order}
                                                    tableId={tableId}
                                                    hasFilter={Boolean(columnFilters[columnDef.id])}
                                                    onSortAsc={() => applySort(columnDef.id, 'asc')}
                                                    onSortDesc={() => applySort(columnDef.id, 'desc')}
                                                    onClearSort={() => applySort(undefined, 'asc')}
                                                    onOpenFilter={(anchor) => setFilterPopover({ columnId: columnDef.id, anchor })}
                                                />
                                            )}
                                        </TableCell>
                                    );
                                })}
                            </TableRow>
                        )
                    }}
                    itemContent={(rowIndex, data) => {
                        return (
                            <>
                                {columnDefs.map((column, colIndex) => {
                                    let backgroundColor = "rgba(255,255,255,0.05)";

                                    return (
                                        <TableCell
                                            key={`col-${colIndex}-row-${rowIndex}`}
                                            sx={{backgroundColor}}
                                            align={column.align || 'left'}
                                        >
                                            {column.format
                                                ? column.format(data[column.id])
                                                : (data[column.id] != null && typeof data[column.id] === 'object'
                                                    ? String(data[column.id])
                                                    : data[column.id])}
                                        </TableCell>
                                    )
                                })}
                            </>
                        )
                    }}
                />
                </Box>
            </Fade>
            {/* Loading-more indicator at the bottom of the scroll area */}
            {isLoadingMore && (
                <Box sx={{
                    position: 'absolute', bottom: 32, left: 0, right: 0, zIndex: 6,
                    display: 'flex', justifyContent: 'center', py: 0.5,
                }}>
                    <CircularProgress size={16} sx={{ color: 'text.secondary' }} />
                </Box>
            )}
            <Paper variant="outlined"
                sx={{ display: 'flex', flexDirection: 'row', position: 'absolute', bottom: 4, right: 20, zIndex: 5 }}>
                <Box sx={{display: 'flex', alignItems: 'center', mx: 1}}>
                    <Typography sx={{display: 'flex', alignItems: 'center', fontSize: '12px'}}>
                        {virtual && <TableIcon sx={{width: 14, height: 14, mr: 1}}/> }
                        {virtual && rowsToDisplay.length < rowCount
                            ? t('dataGrid.loadedOfTotal', { loaded: rowsToDisplay.length, total: rowCount })
                            : t('dataGrid.rowCount', { count: rowCount })}
                    </Typography>
                    {virtual && rowCount > 10000 && (
                        <Tooltip title={t('dataGrid.viewRandomRows')}>
                            <IconButton 
                                size="small" 
                                color="primary" 
                                sx={{marginRight: 1}}
                                onClick={() => {
                                    setOrderBy(undefined);
                                    setOrder('asc');
                                    fetchVirtualData([], 'asc');
                                }}
                            >
                                <CasinoIcon sx={{
                                    fontSize: 18, 
                                    '&:hover': {
                                        transform: 'rotate(180deg)'
                                    }
                                }} />
                            </IconButton>
                        </Tooltip>
                    )}
                    <Tooltip title={isDownloading ? t('dataGrid.downloading') : t('dataGrid.downloadAsCsv')}>
                        <span>
                            <IconButton 
                                size="small" 
                                color="primary" 
                                disabled={isDownloading}
                                onClick={() => handleDownload('csv')}
                            >
                                {isDownloading 
                                    ? <CircularProgress size={16} sx={{ color: 'inherit' }} />
                                    : <FileDownloadIcon sx={{ fontSize: 18 }} />
                                }
                            </IconButton>
                        </span>
                    </Tooltip>
                </Box>
            </Paper>
            {/* Column filter popover — variant chosen synchronously from metadata
                (design-doc 31). Server-side pushdown via fetchVirtualData. */}
            {filterPopover && (() => {
                const meta = tableMetadata?.[filterPopover.columnId];
                const colDef = columnDefs.find(c => c.id === filterPopover.columnId);
                return (
                    <ColumnFilterPopover
                        anchor={filterPopover.anchor}
                        open={true}
                        onClose={() => setFilterPopover(null)}
                        columnId={filterPopover.columnId}
                        columnLabel={colDef?.label || filterPopover.columnId}
                        dataType={colDef?.dataType}
                        distinctCount={meta?.distinctCount}
                        nullCount={meta?.nullCount}
                        levels={meta?.levels}
                        levelCounts={meta?.levelCounts}
                        currentFilter={columnFilters[filterPopover.columnId]}
                        onApply={(f) => {
                            setColumnFilters(prev => {
                                const next = { ...prev };
                                if (f) next[filterPopover.columnId] = f;
                                else delete next[filterPopover.columnId];
                                return next;
                            });
                        }}
                        rowCount={rowCount}
                        isSorted={orderBy === filterPopover.columnId}
                        sortOrder={order}
                        onSortAsc={() => applySort(filterPopover.columnId, 'asc')}
                        onSortDesc={() => applySort(filterPopover.columnId, 'desc')}
                        onClearSort={() => applySort(undefined, 'asc')}
                    />
                );
            })()}
        </Box >
    );
});
