# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

from data_formulator.agent_config import reasoning_effort_for
from data_formulator.agents.agent_utils import generate_data_summary, extract_json_objects
from data_formulator.agents.agent_language import inject_language_instruction

import logging

logger = logging.getLogger(__name__)

_AGENT_ID = "chart_insight"


SYSTEM_PROMPT = r'''You are a data analyst helping users understand their visualizations.
You are given a chart image along with metadata about the chart type, data fields used, and a summary of the underlying data (including schema, value ranges, and sample rows).

Use both the chart image and the data summary to produce:

1. **title**: A short, descriptive title for the chart (5-10 words). It should summarize what the chart is about — the subject, the dimensions compared, and the scope. Do not include the chart type in the title. Write it in title case.

2. **takeaways**: A list of 1-3 key findings or insights from the chart. Each takeaway should be one sentence. Highlight notable patterns, trends, outliers, or comparisons visible in the chart. Be specific — reference actual values, categories, or trends from the data when possible.

Respond with a JSON object in exactly this format (no markdown fences):

{"title": "...", "takeaways": ["...", "..."]}
'''


class ChartInsightAgent(object):

    def __init__(self, client, workspace=None, language_instruction="", knowledge_store=None):
        self.client = client
        self.workspace = workspace
        self.language_instruction = language_instruction
        self._knowledge_store = knowledge_store

    def run(self, chart_image_base64, chart_type, field_names, input_tables=None, n=1):
        """
        Generate insight for a chart.
        
        Args:
            chart_image_base64: Base64-encoded PNG data URL of the chart
            chart_type: The type of chart (e.g., "Bar Chart", "Scatter Plot")
            field_names: List of field names used in the chart encodings
            input_tables: Optional list of input table dicts for data context
            n: Number of candidates to generate
        """

        # Build context about the chart
        context_parts = [f"Chart type: {chart_type}"]
        context_parts.append(f"Fields used: {', '.join(field_names)}")

        if input_tables and self.workspace:
            data_summary = generate_data_summary(
                input_tables, workspace=self.workspace,
                include_data_samples=True, row_sample_size=3,
            )
            context_parts.append(f"\nData summary:\n{data_summary}")

        # Search relevant knowledge for analysis context
        if self._knowledge_store:
            try:
                search_query = " ".join([chart_type] + field_names[:5]).strip()
                if search_query:
                    relevant = self._knowledge_store.search(
                        search_query, categories=["experiences"], max_results=3,
                    )
                    if relevant:
                        kb_parts = ["Relevant analysis knowledge:"]
                        for item in relevant:
                            kb_parts.append(f"- {item['title']}: {item['snippet'][:200]}")
                        context_parts.append("\n".join(kb_parts))
            except Exception:
                logger.warning("Failed to search knowledge experiences", exc_info=True)

        context = "\n".join(context_parts)

        # Build the message with image
        user_content = [
            {
                "type": "text",
                "text": f"[CHART METADATA]\n{context}\n\n[CHART IMAGE]\nHere is the chart to analyze:"
            },
            {
                "type": "image_url",
                "image_url": {
                    "url": f"data:image/png;base64,{chart_image_base64}",
                    "detail": "high"
                }
            }
        ]

        system_prompt = SYSTEM_PROMPT

        if self._knowledge_store:
            system_prompt += self._knowledge_store.format_rules_block()

        system_prompt = inject_language_instruction(system_prompt, self.language_instruction)

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_content}
        ]

        logger.debug(f"ChartInsightAgent: analyzing {chart_type} chart with fields {field_names}")
        logger.info(f"[ChartInsightAgent] run start | chart_type={chart_type}")

        response = self.client.get_completion(messages=messages, reasoning_effort=reasoning_effort_for(_AGENT_ID, self.client.model))

        candidates = []
        for choice in response.choices:
            logger.debug("\n=== Chart insight result ===>\n")
            logger.debug(choice.message.content + "\n")

            response_content = choice.message.content
            title = ""
            takeaways = []

            # Parse JSON response
            json_blocks = extract_json_objects(response_content + "\n")
            for parsed in json_blocks:
                title = parsed.get('title', '')
                takeaways = parsed.get('takeaways', [])
                if isinstance(takeaways, str):
                    takeaways = [takeaways]
                if title or takeaways:
                    break

            if title or takeaways:
                result = {
                    'status': 'ok',
                    'title': title,
                    'takeaways': takeaways,
                }
            else:
                logger.error(f"unable to parse insight from response: {response_content}")
                result = {
                    'status': 'other error',
                    'content': 'unable to generate chart insight'
                }

            result['dialog'] = [*messages, {"role": choice.message.role, "content": choice.message.content}]
            result['agent'] = 'ChartInsightAgent'

            candidates.append(result)

        status = candidates[0].get('status', '?') if candidates else 'empty'
        logger.info(f"[ChartInsightAgent] run done | status={status}")
        return candidates
